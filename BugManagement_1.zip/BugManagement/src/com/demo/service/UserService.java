package com.demo.service;

import com.demo.bean.User;
import com.demo.exception.InvalidUserException;

public interface UserService {

	User validateUser(String userName, String password) throws InvalidUserException ;

}
