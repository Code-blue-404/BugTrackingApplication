package com.demo.service;

import com.demo.dao.RegisterDao;
import com.demo.dao.RegisterDaoImpl;
import com.demo.exception.UserNotFoundException;

public class RegisterServiceImpl implements RegisterService {
	
	RegisterDao ob=new RegisterDaoImpl();

	
	@Override
	public boolean createPassword(String pass,String email,int userid) throws UserNotFoundException {
		return ob.storePassword(pass,email,userid);
	}

	
	@Override
	public int validateEmail(String email, String role) throws UserNotFoundException {
		return ob.emailExistValidation(email,role);
	}
}
