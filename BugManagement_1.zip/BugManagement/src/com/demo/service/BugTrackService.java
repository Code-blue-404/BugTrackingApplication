package com.demo.service;
import java.util.*;

import com.demo.bean.Bug;
import com.demo.bean.Project;
import com.demo.bean.User;
import com.demo.exception.BugNotFoundException;
import com.demo.exception.ErrorInExecutionException;
import com.demo.exception.UserNotFoundException;


public interface BugTrackService {
	

		
		int importUsers(List<User> userList);
		
		List<Project> getAllProjects(int userid);
		
		
		List<Bug> getAllBugs(int projectid);

		
		List<User> getUsersByManager(Integer managerId);

		
		List<Project> getAllPMProjects(int managerid);

		
		boolean closeBug(int bugId)throws BugNotFoundException;
		
		
		boolean assignDev(int bugId, int managerId)throws UserNotFoundException;

		
		void addBug(Bug bug) throws ErrorInExecutionException;

		
		List<User> getAllEmployees(int mgrId);
		
		
		boolean addProject(Project project) throws ErrorInExecutionException;
		
		
		void updateNoOfProjects(int[] userIdChecked) ;
		
		
		void addToTeam(String projectName,int[] userIdChecked,int managerid) throws ErrorInExecutionException;

		
		boolean addRemarks(int bugId, String remarks) throws ErrorInExecutionException;

		
		List<Bug> getAllDevBugs(int projectId, int userId) throws ErrorInExecutionException;
		
		
		Project getPMProject(int projectId) throws ErrorInExecutionException;

		

	}

	

