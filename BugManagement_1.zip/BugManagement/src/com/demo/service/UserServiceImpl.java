package com.demo.service;

import com.demo.bean.User;
import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;
import com.demo.exception.InvalidUserException;

public class UserServiceImpl implements UserService{
	
	private UserDao userDao;

	public UserServiceImpl() {
		userDao = new UserDaoImpl();
	}
	
	
	@Override
	public User validateUser(String userName, String password) throws InvalidUserException  {
		return userDao.validateUser(userName, password);
	}
}
