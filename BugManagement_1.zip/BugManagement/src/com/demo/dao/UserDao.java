package com.demo.dao;

//import java.sql.SQLException;

import com.demo.bean.User;
import com.demo.exception.InvalidUserException;

public interface UserDao {

	
	User validateUser(String userName, String password) throws InvalidUserException;

}
