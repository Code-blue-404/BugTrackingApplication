
package com.demo.dao;

import com.demo.exception.UserNotFoundException;

public interface RegisterDao {

	
	boolean storePassword(String pass,String email, int userid) throws UserNotFoundException;

	
	int emailExistValidation(String email, String role) throws UserNotFoundException;
	
}
