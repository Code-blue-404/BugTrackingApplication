package com.demo.bean;

// Developer is-a relationship with User

public class Developer extends User{

	//default constructor for Developer
	public Developer() {
		
		super();
	}

	//parameterized constructor taking values from User 
	
	public Developer(int userId, String userName, String email, String typeOfUser) {
		
		super(userId, userName, email, typeOfUser);
	}

	@Override
	public String toString() {
		return "Developer []";
	}
	
	
	
}